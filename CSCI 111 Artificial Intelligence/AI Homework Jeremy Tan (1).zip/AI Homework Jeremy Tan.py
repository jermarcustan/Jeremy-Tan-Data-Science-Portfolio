# Jeremy Marcus Tan Code

import math


def square_checker(number):
    if math.ceil(math.sqrt(number)) == math.floor(math.sqrt(number)):
        return True
    else:
        return False


def singular_list(list):
    list = list.copy()
    new_list = []
    for l in list:
        for number in l:
            new_list.append(number)
    return new_list


def sequence_generator(square, list, search_type, initial_number):
    path = []
    index = list.index(square)
    n = list[index]
    while True:
        if search_type == "DFS":
            path.append(list[index])
            index -= 1
            if list[index] == initial_number:
                path.append(list[index])
                break
        elif search_type == "BFS" or search_type == "UCS":
            path.append(int(n))
            if index % 3 == 1:
                n = n + 1
            elif index % 3 == 2:
                n = n - 10
            elif index % 3 == 0:
                n = n / 2
            index = list.index(n)
            if n == initial_number:
                path.append(int(n))
                break
    return path[::-1]


def depth_first_search(sequence):  # We are only concerned with the left branch of the search three (minus 1)
    sequence = sequence.copy()
    i = 0
    checker = False
    while i > -1 and checker == False:
        nodes = sequence[i]
        next_level = []
        for node in nodes:
            if square_checker(node) == True:
                number = node
                checker = True
                break
            else:
                next_level.append(node - 1)
        i += 1
        sequence.append(next_level)
    print(f'For initial number {sequence[0][0]}, the perfect square is {number}')
    new_list = singular_list(sequence)
    path = sequence_generator(number, new_list, "DFS", sequence[0][0])
    print(path)


def breadth_first_search(sequence):
    sequence = sequence.copy()
    i = 0
    checker = False
    while i > -1 and checker == False:
        nodes = sequence[i]
        next_level = []
        for node in nodes:
            if square_checker(node) == True:
                number = node
                checker = True
                break
            else:
                next_level.append(node - 1)
                next_level.append(node + 10)
                next_level.append(node * 2)
        i += 1
        sequence.append(next_level)
    print(f'For initial number {sequence[0][0]}, the perfect square is {number}')
    new_list = singular_list(sequence)
    path = sequence_generator(number, new_list, "BFS", sequence[0][0])
    print(path)


def uniform_cost_search(initial, cost):
    seq = []
    square = 0
    lowest_cost = 0
    priority_queue = {initial: cost}
    checker = False
    while checker != True:
        lowest = min(priority_queue.items(), key=lambda x: x[1])
        number = lowest[0]
        cost = lowest[1]
        priority_queue.pop(number)
        tuple = (number, cost)
        seq.append(tuple)
        if square_checker(number) == True:
            square = number
            lowest_cost = cost
            checker = True
        else:
            priority_queue[number - 1] = cost + 1
            priority_queue[number + 10] = cost + 1
            priority_queue[number * 2] = cost + 5
    print(f'For initial number {initial}, the perfect square is {square} with cost {lowest_cost}')
    sequence = [[initial]]
    i = 0
    checker = False
    while i > -1 and checker == False:
        nodes = sequence[i]
        next_level = []
        for node in nodes:
            if node == square:
                number = node
                checker = True
                break
            else:
                next_level.append(node - 1)
                next_level.append(node + 10)
                next_level.append(node * 2)
        i += 1
        sequence.append(next_level)
    new_list = singular_list(sequence)
    path = sequence_generator(number, new_list, "UCS", sequence[0][0])
    print(f'The path is {path}')
    print(f'The sequence is {seq}')


print("For Depth First Search:")
depth_first_search([[40]])
depth_first_search([[321]])
depth_first_search([[1000]])
print("For Breadth First Search:")
breadth_first_search([[40]])
breadth_first_search([[321]])
breadth_first_search([[1000]])
print("For Uniform Cost Search:")
uniform_cost_search(40, 0)
uniform_cost_search(321, 0)
uniform_cost_search(1000, 0)

